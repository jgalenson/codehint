package note.study;
/**
 * This wrapper can selectively switch between your code
 * and our solutions.  You should ignore it and treat
 * it just like the Utils class.
 */
public class UtilsProxy {

	public static String serialize(Object o) {
		if (Flags.USE_SOLUTION_UTILS)
			return note.study.solution.UtilsSolution.serialize(o);
		else
			return note.Utils.serialize(o);
	}
	
	public static Object deserialize(String s) {
		if (Flags.USE_SOLUTION_UTILS)
			return note.study.solution.UtilsSolution.deserialize(s);
		else
			return note.Utils.deserialize(s);
	}

}
