package note.gui;

import javax.swing.JTextPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.Document;
import javax.swing.undo.UndoManager;

import note.study.UtilsProxy;

/**
 * The text input.
 */
@SuppressWarnings("serial")
public class NoteText extends JTextPane {
	
	private final GUI gui;
	private final UndoManager undo;
	private final UndoableEditListener undoableEditListener;
	private final DocumentListener documentListener;
	
	public NoteText(final GUI gui) {
		this.gui = gui;
		undo = new UndoManager();
		undoableEditListener = new UndoableEditListener() {
			public void undoableEditHappened(UndoableEditEvent e) {
				undo.addEdit(e.getEdit());
				gui.undoChangeHappened(undo);
			}
		};
		getDocument().addUndoableEditListener(undoableEditListener);
		documentListener = new DocumentListener() {
			@Override
			public void insertUpdate(DocumentEvent e) {
				gui.setDirty(true);
			}
			@Override
			public void removeUpdate(DocumentEvent e) {
				gui.setDirty(true);
				
			}
			@Override
			public void changedUpdate(DocumentEvent e) {
				gui.setDirty(true);
				
			}
		};
		getDocument().addDocumentListener(documentListener);
	}
	
	public void openNewNote(String contents) {
		//setText(contents);
		if (contents.length() == 0)
			setDocument(new DefaultStyledDocument());
		else
			setDocument((Document)UtilsProxy.deserialize(contents));
		getDocument().addUndoableEditListener(undoableEditListener);
		getDocument().addDocumentListener(documentListener);
		getStyledEditorKit().getInputAttributes().removeAttributes(getStyledEditorKit().getInputAttributes());
		undo.discardAllEdits();
		gui.undoChangeHappened(undo);
	}
	
	public boolean undo() {
		undo.undo();
		gui.undoChangeHappened(undo);
		return undo.canUndo();
	}
	
	public void redo() {
		undo.redo();
		gui.undoChangeHappened(undo);
	}
	
	public String getContents() {
		getDocument().removeUndoableEditListener(undoableEditListener);
		getDocument().removeDocumentListener(documentListener);
		String result = UtilsProxy.serialize(getDocument());
		getDocument().addUndoableEditListener(undoableEditListener);
		getDocument().addDocumentListener(documentListener);
		return result;
	}
	
}