package memanalyzer;

/**
 * Stores information about the size of the stack.
 */
public class StackInfo {

	private final long numStackFrames;
	private final long totalSize;
	
	/**
	 * Creates information about the size of the stack.
	 * @param numStackFrames The number of stack frames.
	 * @param totalSize The total size of all the frames.
	 */
	public StackInfo(long numStackFrames, long totalSize) {
		this.numStackFrames = numStackFrames;
		this.totalSize = totalSize;
	}

	/**
	 * Gets the number of stack frames.
	 * @return The number of stack frames.
	 */
	public long getNumStackFrames() {
		return numStackFrames;
	}

	/**
	 * Gets the total size of all the stack frames.
	 * @return The total size of all the stack frames.
	 */
	public long getTotalSize() {
		return totalSize;
	}
	
}