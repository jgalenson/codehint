package note.gui;

import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.ListSelectionModel;

import codehint.CodeHint;

/**
 * The list of all notes.  Users can click on the title of
 * a note to open it.
 */
@SuppressWarnings("serial")
public class NoteList extends JList {

	protected final DefaultListModel model;
	protected int selection;

	protected NoteList(final GUI gui, String[] titles) {
		model = new DefaultListModel();
		selection = -1;
		for (String title: titles)
			model.addElement(title);
		setModel(model);
		setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		setDragEnabled(true);  // By itself, this actually disables drag-and-drop.
		addMouseListener(new NoteListMouseListener(gui));
	}
	
	/**
	 * Listener that handles clicks on elements in the list.
	 * We use this to allow the user to click on notes to
	 * open them.  We also manually manage selection, as for
	 * example users might click off the bottom of the list
	 * or click cancel when asked to confirm, so we don't
	 * want to use the list's default selection strategy.
	 */
	private final class NoteListMouseListener extends MouseAdapter {
		
		private final GUI gui;

		private NoteListMouseListener(GUI gui) {
			this.gui = gui;
		}

		public void mouseClicked(MouseEvent e) {
		     if (e.getButton() == MouseEvent.BUTTON1) {
		    	 int index = 0;
		    	 index = getClickedIndex(e);
		    	 System.out.println("Got index: " + index);  // Debugging println for task 2.
		         if (index != -1) {
		        	 if (index == selection)
		        		 return;
		        	 if (!gui.saveAndConfirmIfDirty()) {
		        		 setSelectedIndex(selection);
		        		 return;
		        	 }
		        	 String elem = null;
		        	 elem = getClickedNoteTitle(index);
			    	 System.out.println("Got element: " + elem);  // Debugging println for task 2.
		        	 gui.showNote(elem);
		        	 selection = index;
		         }
		         setSelection();
		      }
		 }

		// Ignore the default selection strategy by overwriting it.
		public void mousePressed(MouseEvent e) {
			setSelection();
		 }
		
		private void setSelection() {
			if (selection == -1)
				clearSelection();
			else
				setSelectedIndex(selection);
		}
		
	}

	/*
	 * TASK 2
	 * ------
	 * Figure out where and on which element the user
	 * clicked by writing the following two methods.
	 * 
	 * Indices are 0-based, so the top element has
	 * index 0, the next 1, etc.
	 * 
	 * If the user did not click a valid element,
	 * getClickedIndex should return -1.
	 * 
	 * getClickedNote can assume that the user did click a
	 * valid element.
	 * 
	 * You should test these methods to ensure that
	 * clicking on a note opens it and clicking on an empty
	 * space does not change the currently-opened note.
	 */

	protected int getClickedIndex(MouseEvent e) {
		 int index = 0;
		 
		 return index;
	 }
	
	protected String getClickedNoteTitle(int index) {
		String elem = null;
		
		return elem;
	}
	
	// End task 2
	
	public void addNote(String title) {
		model.addElement(title);
		selection = model.getSize() - 1;
	}
	
	public String getCurNote() {
		int index = selection;
		if (index == -1)
			return null;
		else
			return (String)model.getElementAt(index);
	}
	
	public void deleteNote() {
		model.removeElementAt(selection);
	}
	
}