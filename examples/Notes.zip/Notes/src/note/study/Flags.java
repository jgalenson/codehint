package note.study;

/**
 * This class contains constants that will selectively
 * enable parts of our solutions.  These should only be
 * used when users cannot complete a task in the given
 * time limit and need to move on.
 * 
 * You should NOT modify this file!
 */
public class Flags {

	protected static final boolean USE_SOLUTION_UTILS = false;
	protected static final boolean USE_SOLUTION_NOTE_LIST = false;
	protected static final boolean USE_SOLUTION_MENU = false;

}
