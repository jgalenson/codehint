package memanalyzer;

/**
 * Stores information about the size in the heap of objects
 * of a certain type.
 */
public class TypeInfo {
	
	private final String typeName;
	private final long numInstances;
	private final long totalSize;
	
	/**
	 * Creates information about the size in the heap of
	 * objects of a certain type.
	 * @param typeName The name of the type.
	 * @param numInstances The number of reachable
	 * instances of this type in the heap.
	 * @param totalSize The total size of all instances of
	 * this type in the heap.
	 */
	public TypeInfo(String typeName, long numInstances, long totalSize) {
		this.typeName = typeName;
		this.numInstances = numInstances;
		this.totalSize = totalSize;
	}

	/**
	 * The name of the type.
	 * @return The name of the type.
	 */
	public String getTypeName() {
		return typeName;
	}

	/**
	 * The number of reachable instances of this type in
	 * the heap.
	 * @return The number of reachable instances of this
	 * type in the heap.
	 */
	public long getNumInstances() {
		return numInstances;
	}

	/**
	 * The total size of all instances of this type in the
	 * heap.
	 * @return The total size of all instances of
	 * this type in the heap.
	 */
	public long getTotalSize() {
		return totalSize;
	}
	
}