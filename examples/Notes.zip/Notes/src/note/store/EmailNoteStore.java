package note.store;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import note.Crypt;


/**
 * Stores notes as emails.
 */
public class EmailNoteStore extends NoteStore {
	
	private static final String HEADER = "X-Note";
	private static final String EMAIL = "joel486@gmail.com";
	private static final String TO_EMAIL = "joel486+note@gmail.com";
	
	private final Crypt crypt;
	
	private final Properties readProps;
	private final Properties sendProps;
	
	public EmailNoteStore(Crypt crypt) {
		this.crypt = crypt;
		readProps = new Properties();
		sendProps = new Properties();
		sendProps.put("mail.smtp.auth", "true");
		sendProps.put("mail.smtp.starttls.enable", "true");
		sendProps.put("mail.smtp.host", "smtp.gmail.com");
		sendProps.put("mail.smtp.port", "587");
	}

	@Override
	public void addEditNote(String title, String contents) {
		deleteNote(title);
		Session session = Session.getInstance(sendProps, new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(EMAIL, crypt.getPassword());
			}
		});
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(EMAIL));
			message.setRecipient(Message.RecipientType.TO, new InternetAddress(TO_EMAIL));
			message.setSubject(crypt.encrypt(title));
			message.setText(crypt.encrypt(contents));
			message.addHeader(HEADER, "");
			Transport.send(message);
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public void deleteNote(String title) {
		try {
			Store store = connect();
			Folder notes = openNotesFolder(store, Folder.READ_WRITE);
			for (Message message: notes.getMessages()) {
				if (crypt.decrypt(message.getSubject()).equals(title)) {
					message.setFlag(Flags.Flag.DELETED, true);
					notes.copyMessages(new Message[] { message }, store.getFolder("[Gmail]/Trash"));
				}
			}
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public String getNote(String title) {
		try {
			for (Message message: connectAndGetNotesFolder(Folder.READ_ONLY).getMessages())
				if (crypt.decrypt(message.getSubject()).equals(title))
					return crypt.decrypt((String)message.getContent());
			return null;
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public String[] listNotes() {
		try {
			List<String> notes = new ArrayList<String>();
			for (Message message: connectAndGetNotesFolder(Folder.READ_ONLY).getMessages()) {
				notes.add(crypt.decrypt(message.getSubject()));
			}
			return notes.toArray(new String[notes.size()]);
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}

	private Store connect() {
		try {
			Session session = Session.getDefaultInstance(readProps, null);
			Store store = session.getStore("imaps");
			store.connect("imap.gmail.com", EMAIL, crypt.getPassword());
			return store;
		} catch (NoSuchProviderException e) {
			throw new RuntimeException(e);
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}

	private Folder connectAndGetNotesFolder(int mode) {
		return openNotesFolder(connect(), mode);
	}

	private static Folder openNotesFolder(Store store, int mode) {
		try {
			Folder folder = store.getFolder("Notes");
			folder.open(mode);
			return folder;
		} catch (NoSuchProviderException e) {
			throw new RuntimeException(e);
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}
	
}
