package memanalyzer.handlers;

import java.util.ArrayList;
import java.util.List;

import memanalyzer.ReportDialog;
import memanalyzer.SizeUtils;
import memanalyzer.StackInfo;
import memanalyzer.TypeInfo;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.model.IStackFrame;
import org.eclipse.debug.core.model.IThread;
import org.eclipse.debug.core.model.IVariable;
import org.eclipse.debug.ui.DebugUITools;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eclipse.jdt.debug.core.IJavaStackFrame;

import codehint.CodeHint;

import com.sun.jdi.ArrayReference;
import com.sun.jdi.ArrayType;
import com.sun.jdi.ClassType;
import com.sun.jdi.InterfaceType;
import com.sun.jdi.ObjectReference;
import com.sun.jdi.ReferenceType;
import com.sun.jdi.VirtualMachine;

@SuppressWarnings("unused")
public class MemoryAnalyzerHandler extends AbstractHandler {
	
	/*
	 * This method is called when the user clicks the
	 * "Analyze Memory" item.  It is a standard part of
	 * Eclipse plugins; in fact, the plugin creation wizard
	 * created an empty version of it for us.
	 */
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		try {
			/*
			 * TASK 1
			 * ------
			 * Find the IThread representing the current
			 * thread and use it to create a StackInfo
			 * object that represents the size of the
			 * stack.
			 * 
			 * Note that you should only do this for the
			 * current thread (i.e., the one that is
			 * stopped at the breakpoint), not for all
			 * threads.
			 */
			IThread curThread = null;
			StackInfo stackInfo = null;
			
			
			/*
			 * TASK 2
			 * ------
			 * Find the VirtualMachine representing the
			 * running VM and use it to get all the loaded
			 * types.  For each loaded type with at least
			 * one instance, create a TypeInfo object that
			 * represents the total size of objects of
			 * exactly that type in the heap.  Also compute
			 * the total size of all objects in the heap.
			 * 
			 * Note that there are multiple ways to get the
			 * number of instances of a given type that can
			 * be inconsistent.  Don't worry about that;
			 * just choose one.
			 */
			VirtualMachine vm = null;
			List<TypeInfo> typeInfos = new ArrayList<TypeInfo>();
			long totalHeapSize = 0;
			

			/*
			 * TASK 3
			 * ------
			 * Create and open a ReportDialog to show the
			 * information to the user.
			 */
			ReportDialog myDialog = null;
			
			myDialog.open();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return null;
	}

}
