package note.store;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import note.Crypt;


/**
 * Stores notes on the file system.
 */
public class FileSystemNoteStore extends NoteStore {
	
	private static final String NOTE_DIR = "/home/joel/tmp/notes-test/";
	
	private final Crypt crypt;
	
	public FileSystemNoteStore(Crypt crypt) {
		this.crypt = crypt;
	}
	@Override
	public void addEditNote(String title, String contents) {
		File file = new File(NOTE_DIR + title );
		write(file, crypt.encrypt(contents));
	}

	@Override
	public void deleteNote(String title) {
		File file = new File(NOTE_DIR + title);
		file.delete();
	}

	@Override
	public String getNote(String title) {
		File file = new File(NOTE_DIR + title);
		return crypt.decrypt(readFile(file));
	}

	@Override
	public String[] listNotes() {
		File dir = new File(NOTE_DIR);
		return dir.list();
	}
	
	private static void write(File file, String s) {
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(file));
			out.write(s);
			out.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
    
    private static String readFile(File file) {
    	 try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			StringBuilder sb = new StringBuilder();
			while (true) {
				String curLine = in.readLine();
				if (curLine == null)
					break;
				sb.append(curLine + "\n");
			}
			in.close();
			return sb.toString();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
    }

}
