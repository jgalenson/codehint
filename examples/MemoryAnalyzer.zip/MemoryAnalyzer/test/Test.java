


@SuppressWarnings("unused")
public class Test {

	public static void main(String[] args) {
		String s = "Hello, world";
		int n = 42;
		Foo foo = new Foo();
		child();
	}
	
	private static void child() {
		System.out.println("Hi!");  // Set a breakpoint here!
	}
	
	private static class Foo {
		int x = 0;
	}

}
