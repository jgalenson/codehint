package note;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;

import note.gui.GUI;

import org.jasypt.exceptions.EncryptionOperationNotPossibleException;
import org.jasypt.util.text.BasicTextEncryptor;

/**
 * This classes handles encryption and decrpytion as well
 * as getting and caching (in memory) the password from the
 * user.
 */
public class Crypt {

	private String password;
	private BasicTextEncryptor textEncryptor;
	
	public Crypt() {
		password = null;
		textEncryptor = null;
	}
	
	public Crypt(String password) {
		this.password = password;
		initEncryptionIfNeeded();
	}

	/**
	 * Encrypts the given string.
	 * @param text The text to encrypt.
	 * @return The given text encrypted by the entered
	 * password.
	 */
	public String encrypt(String text) {
		initEncryptionIfNeeded();
		try {
			return textEncryptor.encrypt(text);
		} catch (EncryptionOperationNotPossibleException e) {
			password = null;
			textEncryptor = null;
			throw new EncryptionException(e);
		}
	}

	/**
	 * Decrypts the given string.
	 * @param text The string to decrypt.
	 * @return The given text decrypted by the entered
	 * password.
	 */
	public String decrypt(String text) {
		initEncryptionIfNeeded();
		try {
			return textEncryptor.decrypt(text);
		} catch (EncryptionOperationNotPossibleException e) {
			password = null;
			textEncryptor = null;
			throw new EncryptionException(e);
		}
	}

	/**
	 * Gets the password the user entered.
	 * @return The password the user entered.
	 */
	public String getPassword() {
		initEncryptionIfNeeded();
		return password;
	}

	/**
	 * Initializes the encryption if necessary by getting
	 * the password from the user.
	 */
	private void initEncryptionIfNeeded() {
		if (textEncryptor == null) {
			getPasswordFromUserIfNeeded();
			textEncryptor = new BasicTextEncryptor();
			textEncryptor.setPassword(password);
		}
	}

	private void getPasswordFromUserIfNeeded() {
		if (password == null) {
			JPanel panel = new JPanel();
			JLabel label = new JLabel("Enter a password:");
			JPasswordField pass = new JPasswordField(10);
			panel.add(label);
			panel.add(pass);
			//int option = JOptionPane.showConfirmDialog(null, panel, "Enter a password", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
			pass.addAncestorListener(new AncestorListener() {
				@Override
				public void ancestorRemoved(AncestorEvent event) {
					event.getComponent().requestFocusInWindow();
				}

				@Override
				public void ancestorMoved(AncestorEvent event) {
					event.getComponent().requestFocusInWindow();
				}

				@Override
				public void ancestorAdded(AncestorEvent event) {
					event.getComponent().requestFocusInWindow();
				}
			});
			int option = JOptionPane.showOptionDialog(GUI.getGUI(), panel, "Enter a password", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, new String[] { "OK", "Cancel" }, "OK");
			if (option == JOptionPane.OK_OPTION)
				password = new String(pass.getPassword());
			else
				throw new EncryptionException("No password entered.");
		}
	}
	
	@SuppressWarnings("serial")
	private static class EncryptionException extends RuntimeException {

		public EncryptionException(String msg) {
			super(msg);
		}

		public EncryptionException(EncryptionOperationNotPossibleException e) {
			super(e);
		}
		
	}

}
