package note.study;

import note.gui.GUI;
import note.gui.Menu;
import note.study.solution.MenuSolution;

/**
 * This wrapper can selectively switch between your code
 * and our solutions.  You should ignore it and treat
 * it just like its supertype.
 */
@SuppressWarnings("serial")
public class MenuProxy extends Menu {

	public MenuProxy(GUI gui) {
		super(gui);
	}

	protected void addStyleMenu() {
		if (Flags.USE_SOLUTION_MENU)
			MenuSolution.addStyleMenu(this);
		else
			super.addStyleMenu();
	}

}
