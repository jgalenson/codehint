package note.gui;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;
import javax.swing.text.DefaultEditorKit;
import javax.swing.undo.UndoManager;

import codehint.CodeHint;


/**
 * The menu items.
 */
@SuppressWarnings("serial")
public class Menu extends JMenuBar {
	
	private final GUI gui;
	private JMenuItem save;
	private JMenuItem delete;
	private JMenuItem cut;
	private JMenuItem copy;
	private JMenuItem paste;
	private JMenuItem undo;
	private JMenuItem redo;

	public Menu(GUI gui) {
		super();
		this.gui = gui;
		addFileMenu();
		addEditMenu();
		addStyleMenu();
	}
	
	private void addFileMenu() {
		JMenu file = new JMenu("File");
		file.setMnemonic(KeyEvent.VK_F);
		
		JMenuItem newMenuItem = new JMenuItem("New");
		newMenuItem.setMnemonic(KeyEvent.VK_N);
		newMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
		newMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!gui.saveAndConfirmIfDirty())
					return;
				while (true) {
					String result = javax.swing.JOptionPane.showInputDialog(gui, "Enter the name of the note.");
					if (result == null)
						break;
					if (!gui.containsNote(result)) {
						gui.addNote(result);
						break;
					}
					javax.swing.JOptionPane.showMessageDialog(gui, "A note of this name already exists.  Please enter a new name.");
				}
			}
		});
		file.add(newMenuItem);
		
		save = new JMenuItem("Save");
		save.setMnemonic(KeyEvent.VK_S);
		save.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));
		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui.saveNote();
			}
		});
		save.setEnabled(false);
		file.add(save);
		
		delete = new JMenuItem("Delete");
		delete.setMnemonic(KeyEvent.VK_D);
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = javax.swing.JOptionPane.showConfirmDialog(gui, "Are you sure you want to delete " + gui.getCurNote() + "?", "Confirm deletion", javax.swing.JOptionPane.YES_NO_OPTION);
				if (result == javax.swing.JOptionPane.YES_OPTION)
					gui.deleteNote();
			}
		});
		delete.setEnabled(false);
		file.add(delete);

		JMenuItem quit = new JMenuItem("Quit");
		quit.setMnemonic(KeyEvent.VK_Q);
		quit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, ActionEvent.CTRL_MASK));
		quit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui.exit();
			}
		});
		file.add(quit);
		
		add(file);
	}
	
	private void addEditMenu() {
		JMenu editMenu = new JMenu("Edit");
		editMenu.setMnemonic(KeyEvent.VK_E);

		cut = new JMenuItem(new DefaultEditorKit.CutAction());
		cut.setText("Cut");
		cut.setMnemonic(KeyEvent.VK_T);
		editMenu.add(cut);
		
		copy = new JMenuItem(new DefaultEditorKit.CopyAction());
		copy.setText("Copy");
		copy.setMnemonic(KeyEvent.VK_C);
		editMenu.add(copy);
		
		paste = new JMenuItem(new DefaultEditorKit.PasteAction());
		paste.setText("Paste");
		paste.setMnemonic(KeyEvent.VK_P);
		editMenu.add(paste);
		
		editMenu.addSeparator();
		
		undo = new JMenuItem("Undo");
		undo.setMnemonic(KeyEvent.VK_U);
		undo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, ActionEvent.CTRL_MASK));
		undo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui.undo();
			}
		});
		undo.setEnabled(false);
		editMenu.add(undo);
		
		redo = new JMenuItem("Redo");
		redo.setMnemonic(KeyEvent.VK_R);
		redo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y, ActionEvent.CTRL_MASK));
		redo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui.redo();
			}
		});
		redo.setEnabled(false);
		editMenu.add(redo);
		
		add(editMenu);
	}
	
	/*
	 * TASK 3
	 * ------
	 * Add menu items that implement bold, italics, and
	 * underline in the specified locations in the
	 * following method.
	 * 
	 * Bold, italic, and underline should both change any
	 * selected text and affect newly-typed text.
	 * 
	 * You should NOT modify the other GUI classes at all
	 * for this task; you should only write code here.
	 * 
	 * Hint: You might want to use the command or action
	 * pattern that the Swing library uses.
	 */
	
	protected void addStyleMenu() {
		JMenu styleMenu = new JMenu("Style");
		styleMenu.setMnemonic(KeyEvent.VK_S);
		
		// Task 3: Add your code for bold, italic, and underline here.
        
		add(styleMenu);
	}
	
	protected void setDirty(boolean b) {
		save.setEnabled(b);
		undo.setEnabled(b);
	}

	protected void undoChangeHappened(UndoManager undo) {
		this.undo.setEnabled(undo.canUndo());
		this.redo.setEnabled(undo.canRedo());
	}
	
	protected void canDelete(boolean b) {
		delete.setEnabled(b);
	}

}
