package note;
import java.util.Arrays;

import note.gui.GUI;
import note.store.EmailNoteStore;
import note.store.FileSystemNoteStore;
import note.store.NoteStore;
import note.study.UtilsProxy;


/**
 * The main class.
 */
public class Notes {

	public static void main(String[] args) {
		serializationTest();
		GUI.start(new FileSystemNoteStore(new Crypt("12345")));
		//GUI.start(new EmailNoteStore(new Crypt()));
	}
	
	/**
	 * Runs some simple unit tests for serialization and
	 * deserialization of Objects to Strings.
	 */
	private static void serializationTest() {
		Integer n = new Integer(42);
		test(UtilsProxy.deserialize(UtilsProxy.serialize(n)).equals(n));
		test(!UtilsProxy.deserialize(UtilsProxy.serialize(n)).equals(new Integer(137)));
		test(UtilsProxy.deserialize(UtilsProxy.serialize(Notes.class)).equals(Notes.class));
	}
	
	/**
	 * Asserts that b holds.  I use this rather than an
	 * actual assertion because (fun Java fact) the assert
	 * keyword is a no-op unless you pass the "-ea" flag,
	 * which means you can easily think you pass all your
	 * tests when in reality they're not running.
	 * @param b The evaluated condition.
	 */
	private static void test(boolean b) {
		if (!b)
			throw new RuntimeException("Assertion failed");
	}

	private static void cmdLineTest() {
		NoteStore store = new FileSystemNoteStore(new Crypt());
		printNoteNames(store);
		printNoteContents(store);
		store.addEditNote("hello", "world!");
		store.addEditNote("this is", "a\ntest");
		printNoteNames(store);
		printNoteContents(store);
		store.deleteNote("this is");
		printNoteNames(store);
		printNoteContents(store);
	}

	private static void cmdLineEmailTest() {
		NoteStore store = new EmailNoteStore(new Crypt());
		printNoteNames(store);
		store.addEditNote("hello", "hello\nworld!");
		printNoteContents(store);
		store.addEditNote("hello", "hello\nworld!\nnew");
		printNoteContents(store);
	}
	
	private static void printNoteNames(NoteStore store) {
		System.out.println(Arrays.toString(store.listNotes()));
	}
	
	private static void printNoteContents(NoteStore store) {
		for (String title: store.listNotes()) {
			System.out.println(title);
			System.out.println("---");
			System.out.println(store.getNote(title));
		}
	}

}
