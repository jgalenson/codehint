package memanalyzer;

import java.util.List;


import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerComparator;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

/**
 * A dialog that reports on information about
 * the memory currently used by the running
 * program.
 */
public class ReportDialog extends Dialog {
	
	private static int WIDTH = 500;
	private static int HEIGHT = 1000;
	
	private TableViewer tableViewer;
	private ReportDialog.MyViewerComparator comparator;
	
	private final List<TypeInfo> typeInfos;
	private final long totalHeapSize; 
	private final StackInfo stackInfo;

	/**
	 * Creates a dialog that reports information about the
	 * memory used by the currently running program.
	 * @param parentShell The parent shell.
	 * @param typeInfos Information about each type that
	 * is loaded.
	 * @param totalHeapSize The total size, in bytes,
	 * of the heap.
	 * @param stackInfo Information about the current
	 * thread's stack.
	 */
	public ReportDialog(Shell parentShell, List<TypeInfo> typeInfos, long totalHeapSize, StackInfo stackInfo) {
		super(parentShell);
		if (parentShell == null || parentShell.getShells().length == 0)
			throw new IllegalArgumentException("Use an existing shell.");
		this.typeInfos = typeInfos;
		this.totalHeapSize = totalHeapSize;
		this.stackInfo = stackInfo;
	}

	@Override
	protected Control createDialogArea(Composite parent) {
		Composite composite = (Composite)super.createDialogArea(parent);

		if (stackInfo != null)  // We check this to avoid crashing if users did not complete the first task and pass in null.
			addLabel(composite, stackInfo.getNumStackFrames() + plural(stackInfo.getNumStackFrames(), " stack frame uses ", " stack frames use ") + stackInfo.getTotalSize() + " bytes.");
		
		addLabel(composite, "Total heap size: " + totalHeapSize + " bytes in " + typeInfos.size() + " types.");
		
		tableViewer = new TableViewer(composite, SWT.BORDER | SWT.MULTI);
		Table table = tableViewer.getTable();
    	table.setLinesVisible(true);
    	table.setHeaderVisible(true);
		comparator = new MyViewerComparator(tableViewer.getTable());
		tableViewer.setComparator(comparator);
        GridData tableData = new GridData(GridData.FILL_BOTH);
        tableData.widthHint = WIDTH;
        tableData.heightHint = HEIGHT;
        table.setLayoutData(tableData);
		TableViewerColumn col1 = addColumn("Type", WIDTH / 2);
		col1.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				TypeInfo type = (TypeInfo)element;
				return type.getTypeName();
			}
		});
		TableViewerColumn col2 = addColumn("Instances", WIDTH / 4);
		col2.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				TypeInfo type = (TypeInfo)element;
				return String.valueOf(type.getNumInstances());
			}
		});
		TableViewerColumn col3 = addColumn("Total size (bytes)", WIDTH / 4);
		col3.setLabelProvider(new ColumnLabelProvider() {
			@Override
			public String getText(Object element) {
				TypeInfo type = (TypeInfo)element;
				return String.valueOf(type.getTotalSize());
			}
		});
    	tableViewer.setContentProvider(new ArrayContentProvider());
    	tableViewer.setInput(typeInfos);
		
		return composite;
	}
    
    private TableViewerColumn addColumn(String label, int width) {
    	final Table table = tableViewer.getTable();
    	final int index = table.getColumnCount();
    	final TableViewerColumn viewerColumn = new TableViewerColumn(tableViewer, SWT.NONE);
    	final TableColumn column = viewerColumn.getColumn();
    	column.setText(label);
    	column.setWidth(width);
    	// Allow users to sort the list of results by various columns.
    	column.addSelectionListener(new SelectionAdapter() {
            @Override
			public void widgetSelected(SelectionEvent e) {
            	final int direction = table.getSortColumn() == column ? (table.getSortDirection() == SWT.DOWN ? SWT.UP : SWT.DOWN) : SWT.DOWN;
            	comparator.setColumn(index);
				table.setSortDirection(direction);
				table.setSortColumn(column);
				tableViewer.refresh();
            }
        });
    	return viewerColumn;
    }
    
    private void addLabel(Composite composite, String message) {
		Label label = new Label(composite, SWT.WRAP);
		label.setText(message);
		label.setFont(composite.getFont());
		GridData gridData = new GridData();
		gridData.widthHint = WIDTH;
		label.setLayoutData(gridData);
    }
    
    // We don't want a Cancel button.
    @Override
	protected void createButtonsForButtonBar(Composite parent) {
    	createButton(parent, org.eclipse.jface.dialogs.IDialogConstants.OK_ID, org.eclipse.jface.dialogs.IDialogConstants.OK_LABEL, true);
    }
	
	private static String plural(long count, String singular, String plural) {
		return count == 1 ? singular : plural;
	}  
    
    // Allow users to sort the list of results by various columns.
    private static class MyViewerComparator extends ViewerComparator {
    	
    	private final Table table;
    	private int column;
    	
    	public MyViewerComparator(Table table) {
    		this.table = table;
    		this.column = 0;
    	}
    	
    	public void setColumn(int column) {
    		this.column = column;
    	}

    	@Override
    	public int compare(Viewer viewer, Object e1, Object e2) {
    		TypeInfo t1 = (TypeInfo)e1;
    		TypeInfo t2 = (TypeInfo)e2;
    		int ret;
    		if (column == 0)
    			ret = t1.getTypeName().compareTo(t2.getTypeName());
    		else if (column == 1)
    			ret = (int)(t1.getNumInstances() - t2.getNumInstances());
    		else if (column == 2)
    			ret = (int)(t1.getTotalSize() - t2.getTotalSize());
    		else
    			throw new RuntimeException("=(");
    		if (table.getSortDirection() == SWT.DOWN)
    			ret = -ret;
    		return ret;
    	}
    	
    }
	
}