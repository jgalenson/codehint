package memanalyzer;

import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.model.IStackFrame;

import com.sun.jdi.ArrayReference;
import com.sun.jdi.ArrayType;
import com.sun.jdi.ClassNotLoadedException;
import com.sun.jdi.ClassType;
import com.sun.jdi.Field;
import com.sun.jdi.ObjectReference;
import com.sun.jdi.ReferenceType;

/**
 * A class that contains utility methods to compute
 * information about the size of objects.
 * 
 * Note that this currently uses heuristics to approximate
 * the sizes and thus will not be exactly correct.  The
 * numbers were adapted from sites such as 
 * http://kohlerm.blogspot.com/2008/12/how-much-memory-is-used-by-my-java.html.
 * Alternative approaches include using the Instrumentation
 * and Unsafe classes.  For details, see
 * http://stackoverflow.com/questions/52353/in-java-what-is-the-best-way-to-determine-the-size-of-an-object.
 */
public class SizeUtils {

	private static int NUM_BITS = Integer.valueOf(System.getProperty("sun.arch.data.model"));
	private static int WORD = NUM_BITS / 8;
	private static int OBJECT_HEADER = 2 * WORD;
	
	/**
	 * Gets the total size in bytes of all objects of the
	 * given type.  Note that this only counts objects
	 * exactly of the given type, not any of its subtypes.
	 * @param type The type.
	 * @param numInstances The number of instances of that
	 * type.
	 * @return The total size in bytes of all objects of
	 * the given type.
	 */
	public static long getTotalSizeOfType(ReferenceType type, long numInstances) {
		if (type instanceof ClassType) {  // Each object of a class has the same size.
			return numInstances * SizeUtils.getClassSize((ClassType)type);
		} else if (type instanceof ArrayType) {  // Each array might have a different size depending on its length.
			long typeSize = 0;
			for (ObjectReference instance: type.instances(Long.MAX_VALUE))
				typeSize += SizeUtils.getArraySize((ArrayReference)instance);
			return typeSize;
		} else  // Interfaces don't have any instances.
			return 0;
	}
	
	/**
	 * Gets the size in bytes of the given stack frame.
	 * @param stack The stack frame.
	 * @return The size in bytes of the given stack frame.
	 * @throws DebugException
	 */
	public static int getStackFrameSize(IStackFrame stack) throws DebugException {
		return (stack.getVariables().length + 1) * SizeUtils.getStackElemSize();
	}

	/**
	 * Gets the size in bytes of all objects of the given
	 * class.
	 * @param clazz The class.
	 * @return The size in bytes of all objects of the
	 * given class.
	 * @throws ClassNotLoadedException
	 */
	private static int getClassSize(ClassType clazz) {
		int size = OBJECT_HEADER;
		for (Field field: clazz.allFields())
			size += shallowSizeOf(field.typeName(), false);
		return round(size);
	}

	/**
	 * Gets the size in bytes of the given array.  This
	 * takes the size of the array into account, unlike
	 * getting the size of a class, which is the same for
	 * all objects of that class.
	 * @param arr The array.
	 * @return The size in bytes of the given array.
	 */
	private static int getArraySize(ArrayReference arr) {
		return round(OBJECT_HEADER + 4 + arr.length() * shallowSizeOf(((ArrayType)arr.type()).componentTypeName(), true));
	}
	
	/**
	 * Gets the size in bytes of elements on the stack.
	 * @return The size in bytes of elements on the stack.
	 */
	private static int getStackElemSize() {
		return round(WORD);
	}

	/**
	 * Gets the shallow size of elements of the given type,
	 * i.e., without following pointers.
	 * @param typeName The name of the type.
	 * @param isArray Whether this element is in an array
	 * or not.  Elements in arrays can be stored more
	 * efficiently.
	 * @return The shallow size of elements of the given
	 * type.
	 */
	private static int shallowSizeOf(String typeName, boolean isArray) {
		if (typeName.equals("boolean") || typeName.equals("byte"))
			return isArray ? 1 : WORD;
		else if (typeName.equals("char") || typeName.equals("short"))
			return isArray ? 2 : WORD;
		else if (typeName.equals("int") || typeName.equals("float"))
			return isArray ? 4 : WORD;
		else if (typeName.equals("long") || typeName.equals("double"))
			return 8;
		else
			return WORD;
	}

	/**
	 * Rounds the given size in bits to the nearest amount
	 * of bytes.
	 * @param size A size in bits.
	 * @return The size in bytes that will hold elements of
	 * the given size in bits.
	 */
	private static int round(int size) {
		return size / 8 + (size % 8 == 0 ? 0 : 1);
	}

}
