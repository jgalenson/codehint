package note;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import javax.xml.bind.DatatypeConverter;

import codehint.CodeHint;

/**
 * A class that contains some utility methods.
 */
@SuppressWarnings("unused")
public class Utils {

	/*
	 * TASK 1
	 * ------
	 * Write the following two methods to serialize and
	 * deserialize an Object to/from a base64-encoded
	 * String.
	 * 
	 * Do NOT serialize the object to disk; put it directly
	 * into a String.
	 * 
	 * Be sure to test to make sure that your serialization
	 * and deserialization methods work and are consistent.
	 * 
	 * Use methods of the standard library (not an external
	 * library) to do base64 encoding/decoding.
	 * 
	 * Hint: Use the ObjectOutputStream and ObjectInputStream
	 * classes to do the actual serialization.
	 */
	
	public static String serialize(Object o) {
		try {
			String result = null;
			
			return result;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static Object deserialize(String s) {
		try {
			Object o = null;
			
			return o;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}
