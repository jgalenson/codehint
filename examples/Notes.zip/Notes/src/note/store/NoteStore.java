package note.store;

/**
 * Abstract class that represents the backing store for
 * the collections of notes.
 */
public abstract class NoteStore {

	public abstract void addEditNote(String title, String contents);
	
	public abstract void deleteNote(String title);
	
	public abstract String getNote(String title);
	
	public abstract String[] listNotes();
	
	public boolean containsNote(String title) {
		for (String note: listNotes())
			if (note.equals(title))
				return true;
		return false;
	}
	
}
