package note.study;

import java.awt.event.MouseEvent;

import note.gui.GUI;
import note.gui.NoteList;
import note.study.solution.NoteListSolution;
/**
 * This wrapper can selectively switch between your code
 * and our solutions.  You should ignore it and treat
 * it just like its supertype.
 */
@SuppressWarnings("serial")
public class NoteListProxy extends NoteList {

	public NoteListProxy(GUI gui, String[] titles) {
		super(gui, titles);
	}

	protected int getClickedIndex(MouseEvent e) {
		if (Flags.USE_SOLUTION_NOTE_LIST)
			return NoteListSolution.getClickedIndex(this, e);
		else
			return super.getClickedIndex(e);
	}

	protected String getClickedNoteTitle(int index) {
		if (Flags.USE_SOLUTION_NOTE_LIST)
			return NoteListSolution.getClickedNoteTitle(model, index);
		else
			return super.getClickedNoteTitle(index);
	}

}
