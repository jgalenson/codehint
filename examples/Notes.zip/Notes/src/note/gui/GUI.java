package note.gui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.SwingUtilities;
import javax.swing.undo.UndoManager;

import note.store.NoteStore;
import note.study.MenuProxy;
import note.study.NoteListProxy;

/**
 * The main GUI class.
 */
@SuppressWarnings("serial")
public class GUI extends JFrame {
	
	private static final int WIDTH = 400;
	private static final int HEIGHT = 400;
	
	private static GUI gui = null;
	
	private final NoteStore store;
	
	private final Map<String, String> unsavedNotes;
	private boolean dirty;
	
	private NoteList noteList;
	private NoteText noteText;
	
	private Menu menu;

	public static void start(final NoteStore store) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				gui = new GUI(store);
			}
		});
	}
	
	public GUI(NoteStore store) {
		super("Swing test");
		this.store = store;
		this.unsavedNotes = new HashMap<String, String>();
		this.dirty = false;
		installMenu();
		installBody();
		setupWindow();
	}
	
	private void installMenu() {
		menu = new MenuProxy(this);
		setJMenuBar(menu);
	}
	
	private void installBody() {
		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		
		noteList = new NoteListProxy(this, store.listNotes());
		
		noteText = new NoteText(this);
		noteText.setEditable(false);
		
		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(noteList), noteText);
		splitPane.setContinuousLayout(true);
		splitPane.setDividerLocation((int)(WIDTH * 0.25));
		add(splitPane);
	}
	
	private void setupWindow() {
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent event) {
				exit();
			}
		});
		pack();
		setVisible(true);
	}
	
	protected boolean containsNote(String title) {
		return store.containsNote(title);
	}
	
	protected String getCurNote() {
		return noteList.getCurNote();
	}
	
	protected void showNote(String title) {
		if (title == null) {
			noteText.openNewNote("");
		} else {
			String contents = unsavedNotes.containsKey(title) ? unsavedNotes.get(title) : store.getNote(title);
			noteText.openNewNote(contents);
		}
		noteText.setEditable(title != null);
		menu.canDelete(title != null);
		setDirty(false);
	}
	
	protected void addNote(String title) {
		unsavedNotes.put(title, "");
		noteList.addNote(title);
		showNote(title);
		noteList.setSelectedValue(title, true);
	}
	
	protected void saveNote() {
		String title = noteList.getCurNote();
		String contents = noteText.getContents();
		store.addEditNote(title, contents);
		if (unsavedNotes.containsKey(title))
			unsavedNotes.remove(title);
		setDirty(false);
	}
	
	protected void deleteNote() {
		String title = noteList.getCurNote();
		noteList.deleteNote();
		showNote(null);
		store.deleteNote(title);
		setDirty(false);
	}
	
	protected void exit() {
		if (!saveAndConfirmIfDirty())
			return;
		dispose();
		System.exit(0);
	}

	protected boolean saveAndConfirmIfDirty() {
		if (dirty)
			return askToSave();
		else
			return true;
	}

	private boolean askToSave() {
		int result = javax.swing.JOptionPane.showConfirmDialog(this, "Save changes first?", "Save?", javax.swing.JOptionPane.YES_NO_CANCEL_OPTION);
		if (result == javax.swing.JOptionPane.YES_OPTION)
			saveNote();
		return result != javax.swing.JOptionPane.CANCEL_OPTION;
	}
	
	protected void undo() {
		boolean canUndoMore = noteText.undo();
		if (!canUndoMore)
			setDirty(false);
	}
	
	protected void redo() {
		noteText.redo();
	}
	
	void setDirty(boolean b) {
		this.dirty = b;
		menu.setDirty(b);
	}

	void undoChangeHappened(UndoManager undo) {
		menu.undoChangeHappened(undo);
	}
	
	public static Component getGUI() {
		return gui;
	}

}
